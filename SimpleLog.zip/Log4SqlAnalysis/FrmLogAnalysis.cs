﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using System.Xml;

namespace Log4SqlAnalysis
{
    public partial class FrmLogAnalysis : Form
    {

        #region 全局变量

        List<XDocument> _logRecordList = new List<XDocument>();//缓存所有选中的log文件

        #endregion

        #region 窗体和控件事件

        public FrmLogAnalysis()
        {
            InitializeComponent();

            //事件绑定
            dtp_stime.ValueChanged += new EventHandler(RefreshDGV);
            dtp_etime.ValueChanged += new EventHandler(RefreshDGV);
            cmb_shour.SelectedIndexChanged += new EventHandler(RefreshDGV);
            cmb_ehour.SelectedIndexChanged += new EventHandler(RefreshDGV);
            lv_logs.ItemChecked += new ItemCheckedEventHandler(RefreshDGV);

            this.AllowDrop = true;
        }

        private void FrmLogAnalysis_Load(object sender, EventArgs e)
        {
            cmb_shour.Items.Clear();
            cmb_ehour.Items.Clear();
            for (int i = 0; i < 24; i++)
            {
                cmb_shour.Items.Add(i);
                cmb_ehour.Items.Add(i);
            }
            cmb_shour.SelectedIndex = 0;
            cmb_ehour.SelectedIndex = 0;

            dgv_result.AllowUserToAddRows = false;
            lv_logs.CheckBoxes = true;
            lv_logs.View = View.List;
        }

        private void 加载日志ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "日志文件|*.log";
            //ofd.DefaultExt = ".log";
            ofd.Multiselect = true;
            ofd.InitialDirectory = "d:";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                var files = ofd.FileNames;
                _logRecordList = new List<XDocument>();
                lv_logs.Items.Clear();

                foreach (var item in files)
                {
                    XDocument xd = XDocument.Load(item);
                    _logRecordList.Add(xd);
                    string fileName = item.Substring(item.LastIndexOf("\\") + 1);
                    lv_logs.Items.Add(new ListViewItem(fileName) { Checked = true });
                }

            }
        }

        private void 清空日志ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _logRecordList = new List<XDocument>();
            dgv_result.DataSource = null;
            lv_logs.Items.Clear();
        }

        //拖拽功能
        private void FrmLogAnalysis_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
            {
                e.Effect = DragDropEffects.All;
            }
        }
        //拖拽功能
        private void FrmLogAnalysis_DragDrop(object sender, DragEventArgs e)
        {

            var files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (var item in files)
            {
                if (item.ToString().ToLower().EndsWith(".log"))
                {
                    string fileName = item.Substring(item.LastIndexOf("\\") + 1);

                    if (_logRecordList.Exists(x => x.Element("records").Attribute("name").Value == fileName)) continue;

                    XDocument xd = XDocument.Load(item);
                    _logRecordList.Add(xd);
                    lv_logs.Items.Add(new ListViewItem(fileName) { Checked = true });
                }
            }
        }

        #endregion

        #region 方法

        private void RefreshDGV(object sender, EventArgs e)
        {

            DateTime stime = dtp_stime.Value.Date.AddHours(double.Parse(cmb_shour.Text == "" ? "0" : cmb_shour.Text));
            DateTime etime = dtp_etime.Value.Date.AddHours(double.Parse(cmb_ehour.Text == "" ? "0" : cmb_ehour.Text));
            var dt = getDgvDT();
            foreach (ListViewItem checkedItem in lv_logs.CheckedItems)
            {

                var selectElements = _logRecordList.Single(x => x.Element("records").Attribute("name").Value.Contains(checkedItem.Text.ToString()));
                if (selectElements != null)
                {
                    var selectValues = selectElements.Root.Elements().Where(x => DateTime.Parse(x.Attribute("systime").Value) > stime && DateTime.Parse(x.Attribute("systime").Value) < etime);

                    foreach (var elementItem in selectValues)
                    {
                        DataRow dr = dt.NewRow();
                        dr["系统时间"] = elementItem.Attribute("systime").Value;
                        dr["执行时间"] = elementItem.Attribute("logtime").Value;
                        dr["执行内容"] = elementItem.Attribute("sqls").Value;
                        dt.Rows.Add(dr);
                    }
                }
            }
            dgv_result.Columns.Clear();
            dgv_result.DataSource = dt;
            dgv_result.Columns[0].Width = 130;
            dgv_result.Columns[1].Width = 130;
            dgv_result.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        //dgv的列表结构
        private DataTable getDgvDT()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("系统时间");
            dt.Columns.Add("执行时间");
            dt.Columns.Add("执行内容");
            return dt;
        }

        #endregion


    }
}
