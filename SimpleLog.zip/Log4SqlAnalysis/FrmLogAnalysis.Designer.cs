﻿namespace Log4SqlAnalysis
{
    partial class FrmLogAnalysis
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lv_logs = new System.Windows.Forms.ListView();
            this.cmb_ehour = new System.Windows.Forms.ComboBox();
            this.dtp_etime = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_shour = new System.Windows.Forms.ComboBox();
            this.dtp_stime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_result = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.加载日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清空日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_result)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1MinSize = 87;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgv_result);
            this.splitContainer1.Size = new System.Drawing.Size(825, 446);
            this.splitContainer1.SplitterDistance = 87;
            this.splitContainer1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.lv_logs);
            this.panel1.Controls.Add(this.cmb_ehour);
            this.panel1.Controls.Add(this.dtp_etime);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cmb_shour);
            this.panel1.Controls.Add(this.dtp_stime);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(825, 87);
            this.panel1.TabIndex = 0;
            // 
            // lv_logs
            // 
            this.lv_logs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lv_logs.BackColor = System.Drawing.SystemColors.Control;
            this.lv_logs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lv_logs.CheckBoxes = true;
            this.lv_logs.Location = new System.Drawing.Point(484, 3);
            this.lv_logs.Name = "lv_logs";
            this.lv_logs.Size = new System.Drawing.Size(341, 81);
            this.lv_logs.TabIndex = 2;
            this.lv_logs.UseCompatibleStateImageBehavior = false;
            this.lv_logs.View = System.Windows.Forms.View.Details;
            // 
            // cmb_ehour
            // 
            this.cmb_ehour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ehour.FormattingEnabled = true;
            this.cmb_ehour.Location = new System.Drawing.Point(420, 32);
            this.cmb_ehour.Name = "cmb_ehour";
            this.cmb_ehour.Size = new System.Drawing.Size(38, 20);
            this.cmb_ehour.TabIndex = 5;
            // 
            // dtp_etime
            // 
            this.dtp_etime.Location = new System.Drawing.Point(288, 32);
            this.dtp_etime.Name = "dtp_etime";
            this.dtp_etime.Size = new System.Drawing.Size(126, 21);
            this.dtp_etime.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(260, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "-";
            // 
            // cmb_shour
            // 
            this.cmb_shour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_shour.FormattingEnabled = true;
            this.cmb_shour.Location = new System.Drawing.Point(204, 30);
            this.cmb_shour.Name = "cmb_shour";
            this.cmb_shour.Size = new System.Drawing.Size(38, 20);
            this.cmb_shour.TabIndex = 4;
            // 
            // dtp_stime
            // 
            this.dtp_stime.Location = new System.Drawing.Point(79, 30);
            this.dtp_stime.Name = "dtp_stime";
            this.dtp_stime.Size = new System.Drawing.Size(119, 21);
            this.dtp_stime.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "时间：";
            // 
            // dgv_result
            // 
            this.dgv_result.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgv_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_result.Location = new System.Drawing.Point(0, 0);
            this.dgv_result.Name = "dgv_result";
            this.dgv_result.RowTemplate.Height = 23;
            this.dgv_result.Size = new System.Drawing.Size(825, 355);
            this.dgv_result.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.加载日志ToolStripMenuItem,
            this.清空日志ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(825, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 加载日志ToolStripMenuItem
            // 
            this.加载日志ToolStripMenuItem.Name = "加载日志ToolStripMenuItem";
            this.加载日志ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.加载日志ToolStripMenuItem.Text = "加载日志";
            this.加载日志ToolStripMenuItem.Click += new System.EventHandler(this.加载日志ToolStripMenuItem_Click);
            // 
            // 清空日志ToolStripMenuItem
            // 
            this.清空日志ToolStripMenuItem.Name = "清空日志ToolStripMenuItem";
            this.清空日志ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.清空日志ToolStripMenuItem.Text = "清空日志";
            this.清空日志ToolStripMenuItem.Click += new System.EventHandler(this.清空日志ToolStripMenuItem_Click);
            // 
            // FrmLogAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 471);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "FrmLogAnalysis";
            this.Text = "日志分析器";
            this.Load += new System.EventHandler(this.FrmLogAnalysis_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.FrmLogAnalysis_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.FrmLogAnalysis_DragEnter);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_result)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dgv_result;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 加载日志ToolStripMenuItem;
        private System.Windows.Forms.DateTimePicker dtp_etime;
        private System.Windows.Forms.DateTimePicker dtp_stime;
        private System.Windows.Forms.ComboBox cmb_shour;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_ehour;
        private System.Windows.Forms.ListView lv_logs;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 清空日志ToolStripMenuItem;
    }
}

