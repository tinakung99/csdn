﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;


public static class Log4Sql
{
    public static void Log(string logmsg)
    {
        string filename = DateTime.Now.ToString("yyyyMMdd") + ".log";
        string fulllogfilename = Path.Combine(Environment.CurrentDirectory, filename);
        //string logContent = string.Format("systime:{0}#logtime{1}#sql:{2}", DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.ToString("yyyyMMdd"), logmsg);
        XDocument xd = File.Exists(fulllogfilename) ?
            XDocument.Load(fulllogfilename) : new XDocument(new XElement("records", new XAttribute("name", filename)));
        XElement record = new XElement("record");
        record.Add(new XAttribute("systime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
        record.Add(new XAttribute("logtime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
        record.Add(new XAttribute("sqls", logmsg));
        xd.Root.Add(record);
        xd.Save(fulllogfilename);
    }
    public static void Log(string logmsg, string logtime)
    {
        string filename = DateTime.Now.ToString("yyyyMMdd") + ".log";
        string fulllogfilename = Path.Combine(Environment.CurrentDirectory, filename + ".log");
        //string logContent = string.Format("systime:{0}#logtime{1}#sql:{2}", DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.ToString("yyyyMMdd"), logmsg);
        XDocument xd = File.Exists(fulllogfilename) ?
            XDocument.Load(fulllogfilename) : new XDocument(new XElement("records", new XAttribute("name", filename)));
        XElement record = new XElement("record");
        record.Add(new XAttribute("systime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
        record.Add(new XAttribute("logtime", logtime));
        record.Add(new XAttribute("sqls", logmsg));
        xd.Root.Add(record);
        xd.Save(fulllogfilename);
    }

}
