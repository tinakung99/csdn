using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MailSent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Email em = new Email();
                em.SendMailByPlainFormat(txtReceive.Text.Trim(), txtCc.Text.Trim(), txtMcc.Text.Trim(), txtSend.Text.Trim(), txtRemark.Text.Trim(), txtHead.Text.Trim(),txtAttachment.Text.Trim(),txtPwd.Text.Trim());
                MessageBox.Show("���ͳɹ���");
            }
            catch
            {
                MessageBox.Show("����ʧ�ܣ�");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtAttachment.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                if (txtAttachment.Text != "")
                {
                    txtAttachment.Text = txtAttachment.Text + ";" + openFileDialog1.FileName;

                }
                else
                {
                    txtAttachment.Text = openFileDialog1.FileName;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}