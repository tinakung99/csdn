﻿using System;
using System.Collections.Generic;
using System.Text;
using MOutlook = Microsoft.Office.Interop.Outlook;

namespace Email_Client
{
    class Outlook
    {
        public void CreateOutlookEmail(string[] information)
        {
            MOutlook.Application outlookApp = new MOutlook.Application();
            MOutlook.MailItem mailItem = (MOutlook.MailItem)outlookApp.CreateItem(MOutlook.OlItemType.olMailItem);

            mailItem.To = information[3].Replace(",", ";");
            mailItem.CC = information[4].Replace(",", ";");
            mailItem.BCC = information[5].Replace(",", ";");
            mailItem.Subject = information[6];
            mailItem.HTMLBody = information[7].Replace("\n","<br/>");
            foreach (string value in information[8].Split(new char[] { ',' }))
            {
                if (!value.Trim().Equals(""))
                {
                    mailItem.Attachments.Add(@"" + value, MOutlook.OlAttachmentType.olByValue, 1, "Attachment Name");
                }
            }

            mailItem.Importance = MOutlook.OlImportance.olImportanceNormal;
            mailItem.Display();
        }
    }
}
