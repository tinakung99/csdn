﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


//using System.Net;
using System.Net.Sockets;
using System.IO;


namespace 收取电子邮件
{
   
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        TcpClient server;//接服务器
        string sendstring;//用于存储POP3服务命令参数
        byte[] bufferstring;//用于存储POP3服务命令参数字节数
        NetworkStream networkstream;//接服务器与服务器进行数据交互
        StreamReader streamreader;//读取信息数据

        private void button2_Click(object sender, EventArgs e)
        {
            server = new TcpClient(this.textBox1.Text, 110);//实例TcpClient 类对象联接服务器
            networkstream = server.GetStream();//实例NetworkStream类对象接收返回发送的数据
            streamreader = new StreamReader(networkstream);//实例StreamReader类对象读取数据

            try
            {
                sendstring = "USER "+this.textBox2.Text+"\r\n";//存储用户名
                bufferstring = Encoding.GetEncoding("gb2312").GetBytes(sendstring.ToCharArray());
                networkstream.Write(bufferstring, 0, bufferstring.Length);//将用户名发送到服务器
                richTextBox1.AppendText(streamreader.ReadLine() + "\r\n");//将用用户显示在 richTextBox控件中
                sendstring = "PASS " + this.textBox3.Text + "\r\n";//存储用户密码
                bufferstring = Encoding.GetEncoding("gb2312").GetBytes(sendstring.ToCharArray());
                networkstream.Write(bufferstring, 0, bufferstring.Length);//将用户密码发送到服务器
                richTextBox1.AppendText(streamreader.ReadLine() + "\r\n");
                sendstring = "STAT " +"\r\n";//储存从服务器获得所有信息序号和字节数命令
                bufferstring = Encoding.GetEncoding("gb2312").GetBytes(sendstring.ToCharArray());
                networkstream.Write(bufferstring, 0, bufferstring.Length);//从服务器获得所有信息序号和字节数
                string strResult=streamreader.ReadLine();//读取从服务器返回的数据
                if (strResult.IndexOf('-') == -1)
                {
                    richTextBox1.AppendText(strResult + "\r\n");
                    sendstring = "LIST " + "\r\n";//存储从服务器中获得信息列表和大小的命令
                    bufferstring = Encoding.GetEncoding("gb2312").GetBytes(sendstring.ToCharArray());
                    networkstream.Write(bufferstring, 0, bufferstring.Length);

                    string strInfo = streamreader.ReadLine();
                    string[] str = strInfo.Split(' ');

                    richTextBox1.AppendText("邮件数量：" + str[1] + "\r\n");
                    richTextBox1.AppendText(str[1] + ":封邮件总容量为" + str[2] + "\r\n");

                    MessageBox.Show(this.textBox2.Text + "用户您好！！！");
                    this.groupBox1.Enabled = false;
                    button1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("读取信息有误，请重新登录");
                }

            }
            catch (Exception ey)
            {
                MessageBox.Show(ey.Message);
            }
        }

        private void Showinfo()
        {
            Cursor cr = Cursor.Current;//定义鼠标信息
            Cursor.Current = Cursors.WaitCursor;
            this.richTextBox1.Clear();
            try
            {
                string strResult = "";
                sendstring = "RETR " + this.textBox4.Text + "\r\n";//存储从服务器获得一条信息的命令
                bufferstring = Encoding.ASCII.GetBytes(sendstring.ToCharArray());
                
                networkstream.Write(bufferstring, 0, bufferstring.Length);


                strResult = streamreader.ReadLine();
                if (strResult[0] != '-')
                {
                    //不断地读取邮件内容，只到结束标志：英文句号
                    while (strResult != ".")
                    {
                        this.richTextBox1.AppendText(strResult + "\r\n");
                        strResult = streamreader.ReadLine();
                       
                    }
                }
                else
                {
                    this.richTextBox1.AppendText("\r\n" + "邮件错误" + "\r\n");
                }
            }
            catch (Exception ey)
            {
                MessageBox.Show(ey.Message);
            }
            
            Cursor.Current = cr;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Showinfo();
            Showinfo();
        }
       
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}