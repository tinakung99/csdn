My Helper
====================
C# Common class helper 4 web
---------------------

* 01.程序配置管理辅助类 MyAppConfigHelper.cs
* 02.实现各种转换的操作辅助类 MyConvertHelper.cs
* 03.DataReader的辅助类 MyDataReaderHelper.cs
* 04.DataTable操作辅助类 MyDataTableHelper.cs
* 05.DateTime的辅助类 MyDateTimeHelper.cs
* 06.常用的目录操作辅助类 MyDirHelper.cs
* 07.枚举操作辅助类 MyEnumHelper
* 08.Excel操作辅助类（无需VBA引用） MyExcelHelper.cs
* 09.打开、保存文件对话框操作辅助类 MyFileDialogHelper.cs
* 10.常用文件操作辅助类 MyFileHelper.cs
* 11.键盘操作辅助类，提供属性访问敲击那个键，以及发送软键盘消息等操作 MyKeyboardHelper.cs。
* 12.Base64加密解密 MyBase64Helper.cs MD5加密等操作辅助类 MyMD5Helper.cs
* 13.鼠标辅助操作类，提供获取鼠标状态以及模拟鼠标点击等操作 MyMouseHelper.cs
* 14.中文转拼音的辅助类 MyPinYinHelper.cs
* 15.字符串类型的辅助类 MyStringHelper.cs
* 16.各种输入格式验证辅助类 MyValidateHelper
* 17.XML操作类辅助类 MyXmlHelper
* 18.FTP操作类辅助类 MyFtpHelper

Initial Version by Yang, Dennis on 23-Jan-2013
[cnBlog][1]

[1]: http://www.cnblogs.com/flashbar/
